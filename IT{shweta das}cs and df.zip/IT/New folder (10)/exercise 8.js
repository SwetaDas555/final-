// Sample array
var myColor = ["Red", "Green", "White", "Black"];

// Joining elements using different methods
var output1 = myColor.toString(); // Using toString() method
var output2 = myColor.join(); // Using join() method with default separator (comma)
var output3 = myColor.join('+'); // Using join() method with custom separator

// Displaying the output
console.log(output1);
console.log(output2);
console.log(output3);